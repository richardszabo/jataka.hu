package hu.rics.alphablender;

import java.io.File;
import java.io.FilenameFilter;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * Git repository creation on 2011-12-19.  
 */
public class AlphaBlenderActivity extends Activity implements
		SeekBar.OnSeekBarChangeListener, OnTouchListener {

	TextView progressTextView;
	ImageView image;
	Bitmap bitmaps[];
	int bitmapsPixels[][];
	TextView filenameTextView[];
	int progress;
	float oldX;
	SeekBar mSeekBar;
	boolean inited = false;
	static boolean DEBUG = true;	

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		progressTextView = (TextView) findViewById(R.id.progress);
		mSeekBar = (SeekBar) findViewById(R.id.seekBar);
		mSeekBar.setOnSeekBarChangeListener(this);
		image = (ImageView) findViewById(R.id.image_view);
		filenameTextView = new TextView[2]; 
		filenameTextView[0] = (TextView) findViewById(R.id.filename1);
		filenameTextView[1] = (TextView) findViewById(R.id.filename2);

		loadFileList();
		bitmaps = new Bitmap[2];
		bitmapsPixels = new int[2][];
		loadImageToBitmap("Mate.jpg",0);
		loadImageToBitmap("Akos.jpg",1);
		
		if( DEBUG ) Log.d(TAG,"Images loaded.");			

		image.setImageBitmap(bitmaps[0]);
		image.setOnTouchListener(this);
		inited = true;
	}
	
	public void browse1(View view) {
		showDialog(DIALOG_LOAD_FILE1);
	}
	 
	public void browse2(View view) {
		showDialog(DIALOG_LOAD_FILE2);
	}
	
	@Override
	public void onProgressChanged(SeekBar arg0, int progress, boolean arg2) {
		this.progress = progress;
		progressTextView.setText("changed:" + progress);
		changeImage();
	}

	void changeImage() {
		int[] result = new int[image.getWidth() * image.getHeight()];
		for (int i = 0; i < image.getWidth() * image.getHeight(); ++i) {
			result[i] = Color.rgb(200, 100, 100);
		}
		long start = System.currentTimeMillis();
		/*progressTextView.setText(":" + bMap.getWidth() + ":" + bMap.getHeight()
				+ ":" + bMap2.getWidth() + ":" + bMap2.getHeight() + ":"
				+ image.getWidth() + ":" + image.getHeight() + ":");*/
		Blend(progress, bitmaps[0].getWidth(), bitmaps[0].getHeight(), bitmapsPixels[0],
				bitmaps[1].getWidth(), bitmaps[1].getHeight(), bitmapsPixels[1],
				image.getWidth(), image.getHeight(), result);
		long end = System.currentTimeMillis();
		if( DEBUG ) Log.d(TAG,"changeImage time:" + (end - start) + ":");					
		// progressTextView.setText("changetime:" + (end-start) + ":");
		// progressTextView.setText("i:" + image.getWidth() + ":" +
		// image.getHeight() + ":");

		Bitmap bmp = Bitmap.createBitmap(image.getWidth(), image.getHeight(),
				Bitmap.Config.ARGB_8888);
		bmp.setPixels(result, 0, image.getWidth(), 0, 0, image.getWidth(),
				image.getHeight());
		image.setImageBitmap(bmp);
	}

	@Override
	public void onStartTrackingTouch(SeekBar arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStopTrackingTouch(SeekBar arg0) {
		// TODO Auto-generated method stub

	}

	public native void Blend(int progress, int rgba1width, int rgba1height,
			int[] rgba1, int rgba2width, int rgba2height, int[] rgba2,
			int width, int height, int[] result);

	static {
		System.loadLibrary("alphablender");
	}

	@Override
	public boolean onTouch(View view, MotionEvent motion) {
		// progressTextView.setText("onTouch");
		int action = motion.getAction();
		int actionCode = action & MotionEvent.ACTION_MASK;
		if (actionCode == MotionEvent.ACTION_DOWN) {
			oldX = motion.getX();
			// progressTextView.setText("motion_down:" + motion.getX() + ":" +
			// motion.getY() + ":");
		}
		if (actionCode == MotionEvent.ACTION_MOVE) {
			progress += (int) (100 * ((motion.getX() - oldX) / image.getWidth()));
			progress = Math.max(Math.min(progress, 100), 0);
			// progressTextView.setText("motion_move:" + motion.getX() + ":" +
			// motion.getY() + ":" + oldX + ":" + progress + ":");
			mSeekBar.setProgress(progress);
			// changeImage();
		}
		return true;
	}

	// In an Activity
	private static final String TAG = "AlphaBlender";
	private String[] mFileList;
	private File mPath = new File(Environment.getExternalStorageDirectory().toString());
	private String mChosenFile;
	private static final String FTYPE = ".jpg";
	private static final int DIALOG_LOAD_FILE1 = 1000;
	private static final int DIALOG_LOAD_FILE2 = 1001;

	private void loadImageToBitmap(String filename,int which/* Bitmap bitmap, int bitmapArray[]*/) {
		String absoluteFilename = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + filename;
		bitmaps[which] = BitmapFactory.decodeFile(absoluteFilename);
		bitmapsPixels[which] = new int[bitmaps[which].getWidth() * bitmaps[which].getHeight()];
		bitmaps[which].getPixels(bitmapsPixels[which], 0, bitmaps[which].getWidth(), 0, 0, bitmaps[which].getWidth(),
				bitmaps[which].getHeight());							
		filenameTextView[which].setText(absoluteFilename);
		if( inited ) {
			changeImage();
		}
	}
	
	private void loadFileList() {
		try {
			mPath.mkdirs();
		} catch (SecurityException e) {
			Log.e(TAG, "unable to write on the sd card " + e.toString());
		}
		if (mPath.exists()) {
			FilenameFilter filter = new FilenameFilter() {
				public boolean accept(File dir, String filename) {
					File sel = new File(dir, filename);
					return filename.contains(FTYPE) || sel.isDirectory();
				}
			};
			mFileList = mPath.list(filter);
		} else {
			mFileList = new String[0];
		}
	}

	protected Dialog onCreateDialog(int id) {
		Dialog dialog = null;
		AlertDialog.Builder builder = new Builder(this);

		switch (id) {
		case DIALOG_LOAD_FILE1:
		case DIALOG_LOAD_FILE2:
			final int i = id == DIALOG_LOAD_FILE1 ? 0:1;
			progressTextView.setText("file:" + i + ":");
			builder.setTitle("Choose your file");
			if (mFileList == null) {
				Log.e(TAG, "Showing file picker before loading the file list");
				dialog = builder.create();
				return dialog;
			}
			builder.setItems(mFileList, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					mChosenFile = mFileList[which];
					loadImageToBitmap(mChosenFile,i);
				}
			});
			break;
		}
		dialog = builder.show();
		return dialog;
	}
}