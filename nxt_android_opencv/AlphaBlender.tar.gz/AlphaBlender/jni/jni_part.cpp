#include <jni.h>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <vector>

using namespace std;
using namespace cv;

extern "C" {
  JNIEXPORT void JNICALL Java_hu_rics_alphablender_AlphaBlenderActivity_Blend(
			  JNIEnv* env, jobject thiz, 
			  jint progress, 
			  jint rgba1width, jint rgba1height, jintArray bgra1, 
			  jint rgba2width, jint rgba2height, jintArray bgra2, 
			  jint width, jint height,jintArray result)
{
    jint*  _bgra1 = env->GetIntArrayElements(bgra1, 0);
    jint*  _bgra2 = env->GetIntArrayElements(bgra2, 0);
    jint*  _result = env->GetIntArrayElements(result, 0);

    Mat mbgra1(rgba1height, rgba1width, CV_8UC4, (unsigned char *)_bgra1);
    Mat mbgra2(rgba2height, rgba2width, CV_8UC4, (unsigned char *)_bgra2);
    Mat mresult(height, width, CV_8UC4, (unsigned char *)_result);

    Mat mbgra1res,mbgra2res; 
    resize(mbgra1, mbgra1res, mresult.size());
    resize(mbgra2, mbgra2res, mresult.size());

    addWeighted(mbgra1res, (100.0-(double)progress)/100.0, mbgra2res, (double)progress/100.0, 0, mresult);
    mbgra1res.release();
    mbgra2res.release();

    env->ReleaseIntArrayElements(bgra1, _bgra1, 0);
    env->ReleaseIntArrayElements(bgra2, _bgra2, 0);
    env->ReleaseIntArrayElements(result, _result, 0);
}

}
